package com.timebuddy.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.format.TextStyle as DayStyle
import java.util.Locale

data class AppInfo(val pkg: String, val label: String)

class MainActivity : ComponentActivity() {
    private var resumes by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { TimeBuddyScreen(resumes) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumes++
    }
}

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .filter { it.pkg != ctx.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun TimeBuddyScreen(resumes: Int) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<AppInfo>()) }
    var tracked by remember { mutableStateOf(Store.tracked(ctx)) }
    var query by remember { mutableStateOf("") }
    var tick by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(TrackerService.running) }
    var dayLimit by remember { mutableIntStateOf(Store.dailyLimitMin(ctx)) }
    var sessLimit by remember { mutableIntStateOf(Store.sessionLimitMin(ctx)) }

    LaunchedEffect(Unit) {
        Store.touch(ctx)
        apps = withContext(Dispatchers.Default) { loadApps(ctx) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(2000)
            tick++
            running = TrackerService.running
        }
    }

    val usageOk = remember(resumes, tick) { hasUsageAccess(ctx) }
    val overlayOk = remember(resumes, tick) { Settings.canDrawOverlays(ctx) }
    val total = remember(tick) { Store.totalToday(ctx) }
    val streak = remember(tick, dayLimit) { Store.streak(ctx) }
    val yesterday = remember(tick) { Store.dayTotal(ctx, LocalDate.now().minusDays(1)) }
    val dayLimitMs = dayLimit * 60_000L
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val filtered = remember(apps, query) { apps.filter { it.label.contains(query, ignoreCase = true) } }

    LazyColumn(
        Modifier.fillMaxSize().systemBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Time Buddy", style = MaterialTheme.typography.headlineLarge)
            Text("Your scroll-time sidekick ⏱️")
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    PermRow("Usage access", usageOk) {
                        ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                    }
                    PermRow("Display over other apps", overlayOk) {
                        ctx.startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                        )
                    }
                    PermRow("Unrestricted battery (recommended)", null) {
                        ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    }
                }
            }
        }
        item {
            Button(
                onClick = {
                    val svc = Intent(ctx, TrackerService::class.java)
                    if (running) {
                        ctx.stopService(svc)
                        Store.setEnabled(ctx, false)
                        running = false
                    } else {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
                            != PackageManager.PERMISSION_GRANTED
                        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        ContextCompat.startForegroundService(ctx, svc)
                        Store.setEnabled(ctx, true)
                        running = true
                    }
                },
                enabled = usageOk && overlayOk,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (running) "Stop timer" else "Start timer") }
        }

        // Today, streak and badges
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Today: ${fmtLong(total)}" + (if (dayLimit > 0) " of ${dayLimit}m" else ""),
                        style = MaterialTheme.typography.titleMedium
                    )
                    if (dayLimit > 0) {
                        val ratio = total.toFloat() / dayLimitMs
                        LinearProgressIndicator(
                            progress = { ratio.coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth(),
                            color = if (ratio >= 1f) MaterialTheme.colorScheme.error
                            else MaterialTheme.colorScheme.primary
                        )
                        Text(if (ratio < 1f) "On track ✅" else "Over the limit 😬")
                    }
                    Text("🔥 $streak-day streak", style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.fillMaxWidth()) {
                        BadgeItem("🌱", "1 day", streak >= 1, Modifier.weight(1f))
                        BadgeItem("🔥", "3 days", streak >= 3, Modifier.weight(1f))
                        BadgeItem("🏆", "7 days", streak >= 7, Modifier.weight(1f))
                        BadgeItem("👑", "30 days", streak >= 30, Modifier.weight(1f))
                        BadgeItem(
                            "😎", "Half hero",
                            dayLimit > 0 && yesterday > 0 && yesterday < dayLimitMs / 2,
                            Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        item { WeekCard(tick, dayLimit) }

        // Limits and alarms
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Limits & alarms", style = MaterialTheme.typography.titleMedium)
                    Stepper("Daily limit", dayLimit, 15, 600) {
                        dayLimit = it
                        Store.setDailyLimitMin(ctx, it)
                    }
                    Stepper("Session alarm", sessLimit, 5, 120) {
                        sessLimit = it
                        Store.setSessionLimitMin(ctx, it)
                    }
                    Text(
                        "When you pass a limit you get a buzz, a sound and a fun popup. 0 = off.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        item {
            Text("Apps to track", style = MaterialTheme.typography.titleMedium)
            Text("${tracked.size} selected", style = MaterialTheme.typography.bodySmall)
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search apps") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        items(filtered, key = { it.pkg }) { app ->
            val isTracked = app.pkg in tracked
            val icon = remember(app.pkg) {
                runCatching {
                    ctx.packageManager.getApplicationIcon(app.pkg).toBitmap(96, 96).asImageBitmap()
                }.getOrNull()
            }
            Row(
                Modifier.fillMaxWidth().clickable {
                    val n = if (isTracked) tracked - app.pkg else tracked + app.pkg
                    tracked = n
                    Store.setTracked(ctx, n)
                },
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (icon != null) Image(icon, contentDescription = null, modifier = Modifier.size(40.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(app.label)
                    if (isTracked) {
                        val used = remember(tick) { Store.usedToday(ctx, app.pkg) }
                        Text(
                            "Today: ${fmtLong(used)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                Checkbox(checked = isTracked, onCheckedChange = null)
            }
        }
    }
}

@Composable
fun WeekCard(tick: Int, dayLimit: Int) {
    val ctx = LocalContext.current
    val days = remember(tick) { (6 downTo 0).map { LocalDate.now().minusDays(it.toLong()) } }
    val totals = remember(tick) { days.map { Store.dayTotal(ctx, it) } }
    val limit = dayLimit * 60_000L
    val maxV = maxOf(totals.max(), limit, 60_000L).toFloat()
    val bar = MaterialTheme.colorScheme.primary
    val red = Color(0xFFC62828)
    val grid = MaterialTheme.colorScheme.outline
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("This week 📊", style = MaterialTheme.typography.titleMedium)
            Canvas(Modifier.fillMaxWidth().height(140.dp)) {
                val slot = size.width / 7f
                val bw = slot * 0.6f
                totals.forEachIndexed { i, t ->
                    val h = size.height * (t.toFloat() / maxV)
                    drawRect(
                        color = if (limit > 0 && t > limit) red else bar,
                        topLeft = Offset(slot * i + (slot - bw) / 2f, size.height - h),
                        size = Size(bw, h)
                    )
                }
                if (limit > 0) {
                    val y = size.height - size.height * (limit.toFloat() / maxV)
                    drawLine(
                        grid, Offset(0f, y), Offset(size.width, y),
                        strokeWidth = 3f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 14f))
                    )
                }
            }
            Row(Modifier.fillMaxWidth()) {
                days.forEachIndexed { i, d ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            d.dayOfWeek.getDisplayName(DayStyle.SHORT, Locale.getDefault()),
                            style = MaterialTheme.typography.labelSmall
                        )
                        Text(fmtShort(totals[i]), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            val nonZero = totals.filter { it > 0 }
            Text(
                "Avg ${fmtLong(totals.average().toLong())}/day" +
                    (if (nonZero.isNotEmpty()) "  ·  Best ${fmtLong(nonZero.min())}" else ""),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
fun BadgeItem(emoji: String, label: String, earned: Boolean, modifier: Modifier) {
    Column(modifier.alpha(if (earned) 1f else 0.3f), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(emoji, style = MaterialTheme.typography.headlineSmall)
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun Stepper(label: String, value: Int, step: Int, max: Int, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        OutlinedButton(
            onClick = { onChange((value - step).coerceAtLeast(0)) },
            modifier = Modifier.size(44.dp),
            contentPadding = PaddingValues(0.dp)
        ) { Text("−") }
        Text(
            if (value == 0) "Off" else "$value m",
            modifier = Modifier.width(64.dp),
            textAlign = TextAlign.Center
        )
        OutlinedButton(
            onClick = { onChange((value + step).coerceAtMost(max)) },
            modifier = Modifier.size(44.dp),
            contentPadding = PaddingValues(0.dp)
        ) { Text("+") }
    }
}

@Composable
fun PermRow(label: String, ok: Boolean?, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label + if (ok == true) "  ✓" else "", Modifier.weight(1f))
        if (ok != true) TextButton(onClick = onClick) { Text(if (ok == null) "Open" else "Grant") }
    }
}
