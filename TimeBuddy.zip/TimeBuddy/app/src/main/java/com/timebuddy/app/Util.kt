package com.timebuddy.app

import android.app.AppOpsManager
import android.content.Context
import android.os.Build
import android.os.Process
import java.time.LocalDate

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("timebuddy", Context.MODE_PRIVATE)
    private fun today() = LocalDate.now().toString()

    fun tracked(c: Context): Set<String> = sp(c).getStringSet("tracked", emptySet()) ?: emptySet()
    fun setTracked(c: Context, s: Set<String>) = sp(c).edit().putStringSet("tracked", HashSet(s)).apply()

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun pos(c: Context): Pair<Int, Int>? {
        val p = sp(c)
        return if (p.contains("ox")) Pair(p.getInt("ox", 0), p.getInt("oy", 0)) else null
    }
    fun setPos(c: Context, x: Int, y: Int) = sp(c).edit().putInt("ox", x).putInt("oy", y).apply()

    fun dailyLimitMin(c: Context) = sp(c).getInt("limit_day", 60)
    fun setDailyLimitMin(c: Context, v: Int) = sp(c).edit().putInt("limit_day", v).apply()
    fun sessionLimitMin(c: Context) = sp(c).getInt("limit_sess", 20)
    fun setSessionLimitMin(c: Context, v: Int) = sp(c).edit().putInt("limit_sess", v).apply()

    fun touch(c: Context) {
        val p = sp(c)
        if (!p.contains("first")) p.edit().putString("first", today()).apply()
    }

    // Days the timer is active (ISO: 1 = Monday ... 7 = Sunday)
    fun daysOn(c: Context): Set<Int> =
        (sp(c).getString("days", null) ?: "1,2,3,4,5,6,7")
            .split(",").mapNotNull { it.trim().toIntOrNull() }.toSet()
    fun setDays(c: Context, s: Set<Int>) =
        sp(c).edit().putString("days", s.sorted().joinToString(",")).apply()
    fun scheduledToday(c: Context) = LocalDate.now().dayOfWeek.value in daysOn(c)

    fun dayApp(c: Context, d: LocalDate, pkg: String): Long = sp(c).getLong("a_${d}_$pkg", 0L)
    fun usedToday(c: Context, pkg: String): Long = dayApp(c, LocalDate.now(), pkg)
    fun dayTotal(c: Context, d: LocalDate): Long = sp(c).getLong("d_$d", 0L)

    // Highest single-app time on a given day
    fun dayMaxApp(c: Context, d: LocalDate): Long {
        val prefix = "a_${d}_"
        var m = 0L
        for ((k, v) in sp(c).all) if (k.startsWith(prefix)) m = maxOf(m, (v as? Long) ?: 0L)
        return m
    }

    fun add(c: Context, pkg: String, ms: Long) {
        val p = sp(c)
        val today = today()
        val e = p.edit()
        if (!p.contains("first")) e.putString("first", today)
        if (p.getString("pruned", "") != today) {
            val cutoff = LocalDate.now().minusDays(60).toString()
            p.all.keys
                .filter { (it.startsWith("d_") || it.startsWith("a_")) && it.substring(2) < cutoff }
                .forEach { e.remove(it) }
            e.putString("pruned", today)
        }
        e.putLong("a_${today}_$pkg", p.getLong("a_${today}_$pkg", 0L) + ms)
        e.putLong("d_$today", p.getLong("d_$today", 0L) + ms)
        e.apply()
    }

    // Consecutive finished scheduled days where every app stayed at or under the limit
    fun streak(c: Context): Int {
        val limit = dailyLimitMin(c) * 60_000L
        if (limit <= 0) return 0
        val days = daysOn(c)
        val firstStr = sp(c).getString("first", null) ?: today()
        val first = try { LocalDate.parse(firstStr) } catch (_: Exception) { LocalDate.now() }
        var d = LocalDate.now().minusDays(1)
        var n = 0
        while (!d.isBefore(first) && n < 365) {
            if (d.dayOfWeek.value in days) {
                if (dayMaxApp(c, d) <= limit) n++ else break
            }
            d = d.minusDays(1)
        }
        return n
    }
}

fun fmtClock(ms: Long): String {
    val s = ms / 1000
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    else "%d:%02d".format(s / 60, s % 60)
}

fun fmtLong(ms: Long): String {
    val m = ms / 60000
    return when {
        m >= 60 -> "${m / 60}h ${m % 60}m"
        m >= 1 -> "${m}m"
        else -> "${ms / 1000}s"
    }
}

fun fmtShort(ms: Long): String {
    val m = ms / 60000
    if (m < 60) return "${m}m"
    val r = "%02d".format(m % 60)
    return "${m / 60}h$r"
}

fun moodFor(ratio: Float): Pair<String, Int> = when {
    ratio < 0.5f -> "😎" to 0xCC2E7D32.toInt()
    ratio < 0.8f -> "🙂" to 0xCC9E9D24.toInt()
    ratio < 1f -> "😬" to 0xCCEF6C00.toInt()
    else -> "😱" to 0xCCC62828.toInt()
}

fun hasUsageAccess(c: Context): Boolean {
    val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    @Suppress("DEPRECATION")
    val mode = if (Build.VERSION.SDK_INT >= 29)
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
    else
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
    return mode == AppOpsManager.MODE_ALLOWED
}
