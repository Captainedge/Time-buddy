package com.timebuddy.app

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat

class TrackerService : Service() {

    companion object {
        @Volatile var running = false
        private const val CHANNEL = "timebuddy_tracker"
        private const val FIVE = 300_000L
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var usm: UsageStatsManager
    private var overlay: TextView? = null
    private var overlayBg: GradientDrawable? = null
    private var popup: View? = null
    private var current: String? = null
    private var sessionMs = 0L
    private var lastTick = 0L
    private var lastQuery = 0L
    private var screenOn = true
    private var idle = false
    private var nextDailyWarn = 0L
    private var nextSessWarn = 0L
    private val labels = HashMap<String, String>()

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            screenOn = i.action == Intent.ACTION_SCREEN_ON
            if (!screenOn) {
                sessionMs = 0L
                nextSessWarn = 0L
                hideOverlay()
            }
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (!Store.scheduledToday(this@TrackerService)) {
                if (!idle) {
                    idle = true
                    current = null
                    sessionMs = 0L
                    hideOverlay()
                    closePopup()
                    updateNotification("Resting today 😴 (not a scheduled day)")
                }
                lastTick = now
                handler.postDelayed(this, 30_000L)
                return
            }
            if (idle) {
                idle = false
                lastQuery = now - 60 * 60 * 1000L
                lastTick = now
                updateNotification("Timing your chosen apps")
            }
            val dt = (now - lastTick).coerceIn(0L, 5000L)
            lastTick = now
            pollForeground(now)
            val pkg = current
            if (screenOn && pkg != null && pkg in Store.tracked(this@TrackerService)) {
                Store.add(this@TrackerService, pkg, dt)
                sessionMs += dt
                val used = Store.usedToday(this@TrackerService, pkg)
                val limitMs = Store.dailyLimitMin(this@TrackerService) * 60_000L
                val sessLimit = Store.sessionLimitMin(this@TrackerService) * 60_000L
                val ratio = if (limitMs > 0) used.toFloat() / limitMs
                else sessionMs.toFloat() / (30 * 60_000L)
                val (emoji, color) = moodFor(ratio)
                showOverlay("$emoji ${label(pkg)}  ·  ${fmtClock(sessionMs)}  ·  today ${fmtLong(used)}", color)
                checkLimits(pkg, used, limitMs, sessLimit)
            } else {
                hideOverlay()
            }
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        screenOn = (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        ContextCompat.registerReceiver(this, screenReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Time Buddy is running")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(1, buildNotification(text))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Time Buddy timer", NotificationManager.IMPORTANCE_LOW)
        )
        val n = buildNotification("Timing your chosen apps")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        idle = false
        lastTick = System.currentTimeMillis()
        lastQuery = lastTick - 60 * 60 * 1000L
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    private fun pollForeground(now: Long) {
        var latest: String? = null
        try {
            val events = usm.queryEvents(lastQuery, now)
            val e = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) latest = e.packageName
            }
        } catch (_: Exception) { }
        lastQuery = now - 1000L
        if (latest != null && latest != current) {
            current = latest
            sessionMs = 0L
            nextDailyWarn = 0L
            nextSessWarn = 0L
        }
    }

    private fun label(pkg: String): String = labels.getOrPut(pkg) {
        try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) { pkg }
    }

    // ---------- limits, alarm and popup ----------

    private fun checkLimits(pkg: String, used: Long, limitMs: Long, sessLimit: Long) {
        if (limitMs <= 0 || used < limitMs) nextDailyWarn = 0L
        if (popup != null) return
        val name = label(pkg)
        if (limitMs > 0 && used >= limitMs && used >= nextDailyWarn) {
            nextDailyWarn = used + FIVE
            val msgs = listOf(
                "$name limit smashed! ${fmtLong(used)} today. Your thumbs need a vacation. 🏖️",
                "Plot twist: today's $name budget is gone. Go touch some grass. 🌱",
                "Time Buddy here! ${fmtLong(used)} of $name today. Future you says thanks if you stop. 🙏",
                "Beep boop, $name limit reached. The feed will still be there tomorrow. 🤖"
            )
            showPopup("🚨 Limit reached!", msgs.random())
        } else if (sessLimit > 0 && sessionMs >= sessLimit && sessionMs >= nextSessWarn) {
            nextSessWarn = sessionMs + FIVE
            val msgs = listOf(
                "You've been in $name for ${fmtLong(sessionMs)} straight. Stretch break? 🧘",
                "$name has had you for ${fmtLong(sessionMs)}. Look at something far away for 20 seconds. 👀",
                "${fmtLong(sessionMs)} nonstop in $name! Drink some water, then decide. 💧"
            )
            showPopup("⏰ Scroll alarm!", msgs.random())
        }
    }

    private fun alarm() {
        try {
            @Suppress("DEPRECATION")
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(700, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) { }
        try {
            RingtoneManager.getRingtone(
                this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            ).play()
        } catch (_: Exception) { }
    }

    private fun showPopup(title: String, msg: String) {
        if (!Settings.canDrawOverlays(this)) return
        alarm()
        val d = resources.displayMetrics.density
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((24 * d).toInt(), (24 * d).toInt(), (24 * d).toInt(), (16 * d).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 28 * d
                setColor(0xF2202030.toInt())
            }
        }
        box.addView(TextView(this).apply {
            text = title
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        box.addView(TextView(this).apply {
            text = msg
            textSize = 16f
            setTextColor(0xFFDDDDDD.toInt())
            gravity = Gravity.CENTER
            setPadding(0, (12 * d).toInt(), 0, (16 * d).toInt())
        })
        box.addView(Button(this).apply {
            text = "Take me home 🏠"
            setOnClickListener { closePopup(); goHome() }
        })
        box.addView(Button(this).apply {
            text = "5 more minutes 😅"
            setOnClickListener { closePopup() }
        })
        val lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            dimAmount = 0.6f
        }
        try {
            wm.addView(box, lp)
            popup = box
        } catch (_: Exception) { }
    }

    private fun closePopup() {
        popup?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        popup = null
    }

    private fun goHome() {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) { }
    }

    // ---------- timer pill ----------

    private fun showOverlay(text: String, color: Int) {
        if (!Settings.canDrawOverlays(this)) return
        val view = overlay ?: createOverlay() ?: return
        overlayBg?.setColor(color)
        view.text = text
    }

    private fun createOverlay(): TextView? {
        val d = resources.displayMetrics.density
        val bg = GradientDrawable().apply {
            cornerRadius = 24 * d
            setColor(0xCC000000.toInt())
        }
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            background = bg
        }
        val saved = Store.pos(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = saved?.first ?: (24 * d).toInt()
            y = saved?.second ?: (48 * d).toInt()
        }
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        tv.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    downX = ev.rawX; downY = ev.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (startX + (ev.rawX - downX)).toInt().coerceAtLeast(0)
                    lp.y = (startY + (ev.rawY - downY)).toInt().coerceAtLeast(0)
                    try { wm.updateViewLayout(v, lp) } catch (_: Exception) { }
                }
                MotionEvent.ACTION_UP -> Store.setPos(this@TrackerService, lp.x, lp.y)
            }
            true
        }
        return try {
            wm.addView(tv, lp)
            overlay = tv
            overlayBg = bg
            tv
        } catch (_: Exception) { null }
    }

    private fun hideOverlay() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        overlay = null
        overlayBg = null
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) { }
        hideOverlay()
        closePopup()
        running = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
