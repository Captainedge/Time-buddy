package com.timebuddy.app

import android.app.AppOpsManager
import android.content.Context
import android.os.Build
import android.os.Process
import java.time.LocalDate

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("timebuddy", Context.MODE_PRIVATE)

    fun tracked(c: Context): Set<String> = sp(c).getStringSet("tracked", emptySet()) ?: emptySet()

    fun setTracked(c: Context, s: Set<String>) =
        sp(c).edit().putStringSet("tracked", HashSet(s)).apply()

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)

    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun pos(c: Context): Pair<Int, Int>? {
        val p = sp(c)
        return if (p.contains("ox")) Pair(p.getInt("ox", 0), p.getInt("oy", 0)) else null
    }

    fun setPos(c: Context, x: Int, y: Int) = sp(c).edit().putInt("ox", x).putInt("oy", y).apply()

    fun usedToday(c: Context, pkg: String): Long {
        val p = sp(c)
        if (p.getString("day", "") != LocalDate.now().toString()) return 0L
        return p.getLong("t_$pkg", 0L)
    }

    fun add(c: Context, pkg: String, ms: Long) {
        val p = sp(c)
        val today = LocalDate.now().toString()
        val e = p.edit()
        if (p.getString("day", "") != today) {
            p.all.keys.filter { it.startsWith("t_") }.forEach { e.remove(it) }
            e.putString("day", today)
            e.putLong("t_$pkg", ms)
        } else {
            e.putLong("t_$pkg", p.getLong("t_$pkg", 0L) + ms)
        }
        e.apply()
    }
}

fun fmtClock(ms: Long): String {
    val s = ms / 1000
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    else "%d:%02d".format(s / 60, s % 60)
}

fun fmtLong(ms: Long): String {
    val m = ms / 60000
    return when {
        m >= 60 -> "${m / 60}h ${m % 60}m"
        m >= 1 -> "${m}m"
        else -> "${ms / 1000}s"
    }
}

fun hasUsageAccess(c: Context): Boolean {
    val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    @Suppress("DEPRECATION")
    val mode = if (Build.VERSION.SDK_INT >= 29)
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
    else
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
    return mode == AppOpsManager.MODE_ALLOWED
}
