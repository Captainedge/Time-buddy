package com.timebuddy.app

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import androidx.core.content.ContextCompat

class TrackerService : Service() {

    companion object {
        @Volatile var running = false
        private const val CHANNEL = "timebuddy_tracker"
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var usm: UsageStatsManager
    private var overlay: TextView? = null
    private var current: String? = null
    private var sessionMs = 0L
    private var lastTick = 0L
    private var lastQuery = 0L
    private var screenOn = true
    private val labels = HashMap<String, String>()

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            screenOn = i.action == Intent.ACTION_SCREEN_ON
            if (!screenOn) {
                sessionMs = 0L
                hideOverlay()
            }
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            val dt = (now - lastTick).coerceIn(0L, 5000L)
            lastTick = now
            pollForeground(now)
            val pkg = current
            if (screenOn && pkg != null && pkg in Store.tracked(this@TrackerService)) {
                Store.add(this@TrackerService, pkg, dt)
                sessionMs += dt
                val today = Store.usedToday(this@TrackerService, pkg)
                showOverlay("${label(pkg)}  ·  ${fmtClock(sessionMs)}  ·  today ${fmtLong(today)}")
            } else {
                hideOverlay()
            }
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        screenOn = (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        ContextCompat.registerReceiver(this, screenReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Time Buddy timer", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Time Buddy is running")
            .setContentText("Timing your chosen apps")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        lastTick = System.currentTimeMillis()
        lastQuery = lastTick - 60 * 60 * 1000L
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    private fun pollForeground(now: Long) {
        var latest: String? = null
        try {
            val events = usm.queryEvents(lastQuery, now)
            val e = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) latest = e.packageName
            }
        } catch (_: Exception) { }
        lastQuery = now - 1000L
        if (latest != null && latest != current) {
            current = latest
            sessionMs = 0L
        }
    }

    private fun label(pkg: String): String = labels.getOrPut(pkg) {
        try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) { pkg }
    }

    private fun showOverlay(text: String) {
        if (!Settings.canDrawOverlays(this)) return
        val view = overlay ?: createOverlay() ?: return
        view.text = text
    }

    private fun createOverlay(): TextView? {
        val d = resources.displayMetrics.density
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 24 * d
                setColor(0xCC000000.toInt())
            }
        }
        val saved = Store.pos(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = saved?.first ?: (24 * d).toInt()
            y = saved?.second ?: (48 * d).toInt()
        }
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        tv.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    downX = ev.rawX; downY = ev.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (startX + (ev.rawX - downX)).toInt().coerceAtLeast(0)
                    lp.y = (startY + (ev.rawY - downY)).toInt().coerceAtLeast(0)
                    try { wm.updateViewLayout(v, lp) } catch (_: Exception) { }
                }
                MotionEvent.ACTION_UP -> Store.setPos(this@TrackerService, lp.x, lp.y)
            }
            true
        }
        return try {
            wm.addView(tv, lp)
            overlay = tv
            tv
        } catch (_: Exception) { null }
    }

    private fun hideOverlay() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        overlay = null
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) { }
        hideOverlay()
        running = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
