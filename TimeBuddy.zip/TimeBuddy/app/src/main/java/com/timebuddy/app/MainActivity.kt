package com.timebuddy.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

data class AppInfo(val pkg: String, val label: String)

class MainActivity : ComponentActivity() {
    private var resumes by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { TimeBuddyScreen(resumes) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumes++
    }
}

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .filter { it.pkg != ctx.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun TimeBuddyScreen(resumes: Int) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<AppInfo>()) }
    var tracked by remember { mutableStateOf(Store.tracked(ctx)) }
    var query by remember { mutableStateOf("") }
    var tick by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(TrackerService.running) }

    LaunchedEffect(Unit) { apps = withContext(Dispatchers.Default) { loadApps(ctx) } }
    LaunchedEffect(Unit) {
        while (true) {
            delay(2000)
            tick++
            running = TrackerService.running
        }
    }

    val usageOk = remember(resumes, tick) { hasUsageAccess(ctx) }
    val overlayOk = remember(resumes, tick) { Settings.canDrawOverlays(ctx) }
    val total = remember(tick, tracked) { tracked.sumOf { Store.usedToday(ctx, it) } }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val filtered = remember(apps, query) { apps.filter { it.label.contains(query, ignoreCase = true) } }

    LazyColumn(
        Modifier.fillMaxSize().systemBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text("Time Buddy", style = MaterialTheme.typography.headlineLarge)
            Text("Today: ${fmtLong(total)} across ${tracked.size} tracked apps")
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    PermRow("Usage access", usageOk) {
                        ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                    }
                    PermRow("Display over other apps", overlayOk) {
                        ctx.startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                        )
                    }
                    PermRow("Unrestricted battery (recommended)", null) {
                        ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    }
                }
            }
        }
        item {
            Button(
                onClick = {
                    val svc = Intent(ctx, TrackerService::class.java)
                    if (running) {
                        ctx.stopService(svc)
                        Store.setEnabled(ctx, false)
                        running = false
                    } else {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
                            != PackageManager.PERMISSION_GRANTED
                        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        ContextCompat.startForegroundService(ctx, svc)
                        Store.setEnabled(ctx, true)
                        running = true
                    }
                },
                enabled = usageOk && overlayOk,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (running) "Stop timer" else "Start timer") }
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search apps") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        items(filtered, key = { it.pkg }) { app ->
            val isTracked = app.pkg in tracked
            val icon = remember(app.pkg) {
                runCatching {
                    ctx.packageManager.getApplicationIcon(app.pkg).toBitmap(96, 96).asImageBitmap()
                }.getOrNull()
            }
            Row(
                Modifier.fillMaxWidth().clickable {
                    val n = if (isTracked) tracked - app.pkg else tracked + app.pkg
                    tracked = n
                    Store.setTracked(ctx, n)
                },
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (icon != null) Image(icon, contentDescription = null, modifier = Modifier.size(40.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(app.label)
                    if (isTracked) {
                        val used = remember(tick) { Store.usedToday(ctx, app.pkg) }
                        Text(
                            "Today: ${fmtLong(used)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                Checkbox(checked = isTracked, onCheckedChange = null)
            }
        }
    }
}

@Composable
fun PermRow(label: String, ok: Boolean?, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label + if (ok == true) "  ✓" else "", Modifier.weight(1f))
        if (ok != true) TextButton(onClick = onClick) { Text(if (ok == null) "Open" else "Grant") }
    }
}
